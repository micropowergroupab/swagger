import { StatusBar } from 'expo-status-bar';
import React from 'react';
import {StyleSheet, FlatList, Text, TextInput, View, Image, Button, TouchableOpacity, ScrollView } from 'react-native';

import { NavigationContainer} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

export default function App() {
  const stack = createNativeStackNavigator();

  return(
    <NavigationContainer>
      <stack.Navigator>
        <stack.Screen name = 'Home' component ={Home}/>
        <stack.Screen name = 'ReportLoading' component ={ReportLoading}/>
        <stack.Screen name = 'ReportGuide' component ={ReportGuide}/>
        <stack.Screen name = 'DailySummary' component ={DailySummary}/>
        <stack.Screen name = 'MonthlySummary' component ={MonthlySummary}/>
        <stack.Screen name = 'Result' component ={Result}/>
        <stack.Screen name = 'About' component ={About}/>
      </stack.Navigator>
    </NavigationContainer>
  )

  function Home({navigation}){
    return (
      <View style={styles.containerhome}>
        <Text style ={styles.text_style_title}> Your Battery Report</Text>
        <Image source={require('./battery1.png')} style={styles.image_style}/>
        <TouchableOpacity onPress={()=>{navigation.navigate('ReportLoading')}}>
          <Text style ={styles.text_style_button}> Report</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>{navigation.navigate('About')}}>
          <Text style ={styles.text_style_button}> About</Text>
        </TouchableOpacity>
        
      </View>
    );

  }

  function ReportLoading({navigation}){
    const [astr, set_astr] = React.useState('');
    return (
      <View style={styles.container}>
        <Image source={require('./battery2.png')} style={{height:350, width:380, marginBottom: 20}}/>
        <Text style ={styles.text_style_text}> BatteryID: </Text>
        <TextInput
          style={styles.text_input}
          placeholder = 'Input your battery ID (1 or 2)'
          onChangeText = {(astr) => set_astr(astr)}
        />
        <TouchableOpacity onPress={()=>{navigation.navigate('ReportGuide')}}>
          <Text style ={{fontSize: 20, color: '#2196f3', fontWeight: 500}}> Load</Text>
        </TouchableOpacity>
      </View>
    );
  }

  function ReportGuide({navigation}){
    const [bstr, set_bstr] = React.useState('');
    return (
      <View style={styles.container}>
        <Text style ={styles.text_style_title}> Report for Battery 2</Text>
        <Image source={require('./battery3.png')} style={{height:350, width:380, marginBottom: 20}}/>
        <TouchableOpacity onPress={()=>{navigation.navigate('DailySummary')}}>
          <Text style ={{fontSize: 20, color: '#2196f3', fontWeight: 500}}> Daily Summary</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>{navigation.navigate('MonthlySummary')}}>
          <Text style ={{fontSize: 20, color: '#2196f3', fontWeight: 500}}> Monthly Summary</Text>
        </TouchableOpacity>    
        <Text style ={{fontSize: 20, fontWeight: 500}}> Date: </Text>
        <TextInput
          style={styles.text_input}
          placeholder = 'xxxx-xx-xx'
          onChangeText = {(bstr) => set_bstr(bstr)}
        />
        <TouchableOpacity onPress={()=>{navigation.navigate('Result')}}>
          <Text style ={{fontSize: 20, color: '#2196f3', fontWeight: 500}}> Load Daily Monitoring</Text>
        </TouchableOpacity>
      </View>
    );
  }
  function DailySummary({navigation}){
    return (
      <View style={styles.container1}>
        <Text style ={styles.text_style_subtitle}> Battery 2 Daily Summary</Text>
        <Text style ={styles.text_style_text2}> Average Idle Time: 8.97 hours</Text>
        <Text style ={styles.text_style_text2}> Average High Temperature: 1.27 hours</Text>
        <Text style ={styles.text_style_text2}> Average Charge Time: 0.86 hours</Text>
        <Text style ={styles.text_style_text2}> Average Regen Charge Times: 0 Times</Text>
        <ScrollView style={styles.scrollView}>
            <Image source={require('./dre1.png')} style={styles.image_style2}/>
            <Image source={require('./dre2.png')} style={styles.image_style2}/>
            <Image source={require('./dre3.png')} style={styles.image_style2}/>
            <Image source={require('./dre4.png')} style={styles.image_style2}/>
        </ScrollView>      
      </View>
    ); 
  }

  function MonthlySummary({navigation}){
    return (
      <View style={styles.container1}>
        <Text style ={styles.text_style_subtitle}> Battery 2 Monthly Summary</Text>
        <ScrollView style={styles.scrollView}>
            <Image source={require('./mre1.png')} style={styles.image_style2}/>
            <Image source={require('./mre2.png')} style={styles.image_style2}/>
            <Image source={require('./mre3.png')} style={styles.image_style2}/>
            <Image source={require('./mre4.png')} style={styles.image_style2}/>
        </ScrollView>      
      </View>
    ); 
  }


  function Result({navigation}){
    return (
      <View style={styles.container1}>
        <Text style ={styles.text_style_subtitle}> Battery 2 on 2022-11-30</Text>
        <Text style ={styles.text_style_text2}> Idle time lasts: 2.72 hours</Text>
        <Text style ={styles.text_style_text2}> High Battary Temperature: 0 hours</Text>
        <Text style ={styles.text_style_text2}> Regen charge: 0 Times</Text>
        <ScrollView style={styles.scrollView}>
            <Image source={require('./re1.png')} style={styles.image_style2}/>
            <Image source={require('./re2.png')} style={styles.image_style2}/>
            <Image source={require('./re3.png')} style={styles.image_style2}/>
            <Image source={require('./re4.png')} style={styles.image_style2}/>
        </ScrollView>      
      </View>
    ); 
  }

  function About({navigation}){
    return (
      <View style={styles.container}>
        <Text style ={styles.text_style2}> Written by: </Text>
        <Text style ={styles.text_style2}> Yurong Li </Text>
        <Text style ={styles.text_style2}> yurong0889@outlook.com</Text>
      </View>
    );
    
  }
}

const styles = StyleSheet.create({
  image_style:{
    flex: 0.6,
  },
  image_style2:{
    flex: 0.1,
  },
  text_style_title:{
    fontSize: 40, 
    fontWeight: 'bold',
  },
  text_style_button:{
    fontSize: 30, 
    color: '#2196f3', 
    fontWeight: 500,
  },
  text_style_text:{
    fontSize: 25,
    fontWeight: 500,
  },
  text_style_text2:{
    fontSize: 20,
    fontWeight: 500,
    textAlign:'left',
    marginLeft: 20
  },
  text_style_subtitle:{
    lineHeight: 100,
    fontWeight: 'bold',
    color: '#2196f3',
    fontSize: 28,
    textAlign: 'center'
  },
  text_input:{
    textAlign:'center',
    fontSize:20,
    height:40,
    width:300,
    backgroundColor:'lightyellow'
  },
  containerhome: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollView: {
    marginTop:20,
    marginHorizontal: 5,
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  container1: {
    flex: 1,
    paddingTop: 0,
    backgroundColor: '#fff',
  },
});


